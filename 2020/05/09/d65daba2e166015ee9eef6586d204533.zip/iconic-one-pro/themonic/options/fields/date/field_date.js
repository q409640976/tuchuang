/*global jQuery, document*/
jQuery(document).ready(function () {
    /*
     *
     * Themonic_Options_date function
     * Adds datepicker js
     *
     */
    jQuery('.themonic-opts-datepicker').datepicker();
});
