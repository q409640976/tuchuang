<?php
/*
 * The template used for displaying page content in page.php
 *
 * @package Iconic One Pro
 * 
 * @since Iconic One Pro 1.0
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<center><?php the_post_thumbnail('post-thumbnail'); ?></center>
		
	<?php if ( !is_page_template('page-templates/no-title.php') && !is_page_template('page-templates/no-title-full-width.php')  ) : ?>		
			<header class="entry-header">
				<h1 class="entry-title"><?php the_title(); ?></h1>
			</header>
	<?php endif; ?>

		<div class="entry-content">
			<?php the_content(); ?>
			<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'themonic' ), 'after' => '</div>' ) ); ?>
		</div><!-- .entry-content -->
		<footer class="entry-meta">
			<?php edit_post_link( __( 'Edit', 'themonic' ), '<span class="edit-link">', '</span>' ); ?>
		</footer><!-- .entry-meta -->
	</article><!-- #post -->
